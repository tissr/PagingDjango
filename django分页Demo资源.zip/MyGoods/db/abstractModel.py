from django.db import models


class AbstractModel(models.Model):

    real_del = models.BooleanField(default=False)

    update_time = models.DateTimeField(auto_now=True)

    create_time = models.DateTimeField(auto_now_add=True)


    class Meta:
        abstract = True
from django.db import models
from db.abstractModel import AbstractModel
# Create your models here.

class ShowMyComputer(AbstractModel):

    goods_name = models.CharField(max_length=100)

    goods_image = models.ImageField()




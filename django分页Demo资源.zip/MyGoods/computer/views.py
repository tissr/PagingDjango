from django.shortcuts import render
from .models import ShowMyComputer
# 引入方法
from django.core.paginator import Paginator
# Create your views here.

def show(request, page_id):

    # 获取需要分页的对象集合
    all_goods = ShowMyComputer.objects.all()

    # 创建分页对象
    paginator = Paginator(all_goods, 3)

    # 根据当前页码,确定返回的数据
    current_page = paginator.page(page_id)

    # 保证前端取到的"页数"为整型
    page_id = int(page_id)


    return render(request, 'computer/list.html', locals())
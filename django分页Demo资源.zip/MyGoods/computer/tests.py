from django.test import TestCase
from .models import ShowMyComputer

import os
# Create your tests here.

my_path = '/Users/lijianzhao/Desktop/MyGoods/MyGoods/static/images'

img_list = os.listdir(my_path)


print(img_list)

for img in img_list:

    mc = ShowMyComputer()

    mc.goods_name = img

    mc.goods_image = 'images/' + img

    mc.save()
